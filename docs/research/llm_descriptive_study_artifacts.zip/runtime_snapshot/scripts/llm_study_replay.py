from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import time
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from langgraph.checkpoint.memory import MemorySaver

from gateway_uncertainty_ablation import gate_class
from twinloop.actions.schema import ParseError, parse_action
from twinloop.agent.llm_agent import LLMAgent
from twinloop.config import EvaluationConfig, ExperimentConfig, FaultConfig, GraphConfig, LLMConfig, SimConfig, TwinConfig
from twinloop.experiment import runner
from twinloop.experiment.arms import RunSpec
from twinloop.llm.budget import BudgetGuard
from twinloop.llm.cache import CacheMiss, ResponseCache
from twinloop.llm.client import LLMClient
from twinloop.twin.validator import TwinValidator

FIELDS = (
    "seed", "tick", "decision_index", "proposal_index", "retry_index", "proposed_action",
    "schema_valid", "semantically_valid", "twin_verdict", "twin_reason", "was_applied",
    "twin_predicted_violation_ticks_action", "twin_predicted_violation_ticks_noop",
    "counterfactual_violation_ticks_action", "counterfactual_violation_ticks_noop",
    "counterfactual_harm_delta", "ground_truth_harmful", "decision_outcome", "decision_fallback",
    "decision_trace", "exhausted", "prompt_version",
)
ARMS = ("ungated", "always_reject", "twin@1.0", "twin@0.6")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class NoNetworkProvider:
    def __init__(self):
        self.calls = 0

    def complete(self, *args, **kwargs):
        self.calls += 1
        raise AssertionError("Network provider is disabled for this audit")


class AuditedCache(ResponseCache):
    def __init__(self, path):
        super().__init__(path, cache_only=True)
        self.lookups = []

    def get(self, key):
        value = super().get(key)
        self.lookups.append({"key": key, "hit": value is not None})
        return value

    def put(self, key, value):
        raise AssertionError("Source response cache is read-only during audit")


class RecordedAgent:
    name = "llm"
    prompt_version = "v1"

    def __init__(self, records, cached_agent, cache):
        self.records = records
        self.cached_agent = cached_agent
        self.cache = cache
        self.index = 0
        self.last_trace = {}
        self.cache_audit = []

    def set_context(self, context):
        self.cached_agent.set_context(context)

    def decide(self, obs, feedback=None):
        if self.index >= len(self.records):
            raise AssertionError("Replay requested an extra proposal")
        recorded = self.records[self.index]
        if obs.tick != recorded["tick"]:
            raise AssertionError(f"Replay tick differs: {obs.tick} != {recorded['tick']}")
        if (feedback is not None) != recorded["decision_trace"]["feedback_present"]:
            raise AssertionError("Replay feedback availability differs")
        action = parse_action(recorded["proposed_action"])
        if isinstance(action, ParseError):
            raise AssertionError(action.message)
        start = len(self.cache.lookups)
        audit = {"tick": obs.tick, "retry_index": recorded["retry_index"],
                 "historical_outcome": recorded["decision_outcome"]}
        try:
            cached_action = self.cached_agent.decide(obs, feedback)
            audit["status"] = "matched" if (
                cached_action.model_dump() == recorded["proposed_action"]
                and self.cached_agent.last_trace == recorded["decision_trace"]
            ) else "different"
            if audit["status"] == "different":
                audit["cached_action"] = cached_action.model_dump()
                audit["cached_outcome"] = self.cached_agent.last_trace["outcome"]
                audit["trace_fields_differing"] = [
                    key for key in set(self.cached_agent.last_trace) | set(recorded["decision_trace"])
                    if self.cached_agent.last_trace.get(key) != recorded["decision_trace"].get(key)
                ]
        except CacheMiss as error:
            audit["status"] = "cache_miss"
            audit["error"] = str(error)
        self.cached_agent._last_proposed = action
        audit["lookups"] = self.cache.lookups[start:]
        self.cache_audit.append(audit)
        self.last_trace = deepcopy(recorded["decision_trace"])
        self.index += 1
        return action


def replay_one(arguments):
    source_text, output_text, shard_name = arguments
    source = Path(source_text)
    output = Path(output_text)
    original = json.loads((source / "shards" / shard_name).read_text(encoding="utf-8"))
    arm, seed = original["arm"], original["seed"]
    cache_directory = "cache" if seed < 2 else f"cache_w{seed % 4}"
    cache = AuditedCache(source / cache_directory / "cache.json")
    config = ExperimentConfig(
        sim=SimConfig(episode_ticks=120), fault=FaultConfig(gateway_faultable=False),
        graph=GraphConfig(decision_interval_ticks=10, retry_cap=2),
        twin=TwinConfig(horizon_ticks=20, tolerance_margin=0.0),
        evaluation=EvaluationConfig(harm_threshold_ticks=3),
        llm=LLMConfig(provider="gemini", model="gemini-3.6-flash", temperature=0.0,
                      cache_only=True, cache_dir=str(source / cache_directory),
                      max_calls=0, max_tokens=0, timeout_seconds=30.0,
                      react_timeout_seconds=20.0, react_max_steps=4, prompt_version="v1"),
    )
    provider = NoNetworkProvider()
    budget = BudgetGuard(0, 0)
    episode_output = output / "replay_work" / Path(shard_name).stem
    client = LLMClient(provider, config.llm, cache=cache, budget=budget,
                       log_path=episode_output / "cache_lookups.jsonl")
    agent = RecordedAgent(original["records"], LLMAgent(client, config.llm, config.slo, config.actions), cache)
    gate = gate_class("always_reject") if arm == "always_reject" else TwinValidator
    with patch.object(runner, "_make_agent", return_value=agent), patch.object(runner, "TwinValidator", gate):
        summary, _, records = runner.run_single(
            config, RunSpec("LLM", "llm", original["gated"], seed, original["fidelity"]),
            episode_output, lambda: provider, budget, cache, True, MemorySaver(),
        )
    mismatches = []
    for historical_key, replay_key in (("violation_ticks", "slo_violation_ticks"),
                                       ("proposals", "proposals"), ("rejections", "rejections"),
                                       ("retries", "retries")):
        if original[historical_key] != summary[replay_key]:
            mismatches.append({"field": historical_key, "original": original[historical_key],
                               "replay": summary[replay_key]})
    if len(records) != len(original["records"]):
        mismatches.append({"field": "record_count", "original": len(original["records"]), "replay": len(records)})
    for index, (old, new) in enumerate(zip(original["records"], records)):
        for field in FIELDS:
            if old.get(field) != new.get(field):
                mismatches.append({"record": index, "field": field,
                                   "original": old.get(field), "replay": new.get(field)})
    if agent.index != len(original["records"]):
        mismatches.append({"field": "unconsumed_proposals", "count": len(original["records"]) - agent.index})
    return {"arm": arm, "seed": seed, "source_shard": shard_name,
            "violation_ticks": summary["slo_violation_ticks"], "decision_points": summary["proposals"],
            "attempts": len(records), "non_noop_candidates": sum(r["proposed_action"]["type"] != "no_op" for r in records),
            "mismatches": mismatches, "cache_directory": cache_directory,
            "cache_attempt_status": dict(Counter(r["status"] for r in agent.cache_audit)),
            "cache_attempts": agent.cache_audit, "provider_calls": provider.calls,
            "budget_calls": budget.calls, "budget_tokens": budget.tokens}


def archive_artifacts(source, output, archive_path):
    archive_path = Path(archive_path)
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in sorted(source.rglob("*")):
            if path.is_file():
                bundle.write(path, "source/" + path.relative_to(source).as_posix())
        for name in ("source_manifest.json", "replay_audit.json"):
            if (output / name).exists():
                bundle.write(output / name, name)
        bundle.write(Path(__file__), "scripts/llm_study_replay.py")
    return {"path": str(archive_path.relative_to(ROOT)) if archive_path.is_relative_to(ROOT) else str(archive_path),
            "bytes": archive_path.stat().st_size, "sha256": sha256(archive_path)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=ROOT / "results/llm_descriptive_study/source")
    parser.add_argument("--output", type=Path, default=ROOT / "results/llm_descriptive_study")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--archive", type=Path, default=ROOT / "docs/research/llm_descriptive_study_artifacts.zip")
    parser.add_argument("--archive-only", action="store_true")
    args = parser.parse_args()
    if args.archive_only:
        print(json.dumps(archive_artifacts(args.source, args.output, args.archive), indent=2))
        return
    started = time.perf_counter()
    args.output.mkdir(parents=True, exist_ok=True)
    paper_before = sha256(ROOT / "paper/main.tex")
    manifest = json.loads((args.output / "source_manifest.json").read_text(encoding="utf-8"))
    artifact_mismatches = [entry["path"] for entry in manifest["files"]
                           if sha256(args.source / entry["path"]) != entry["sha256"]]
    shards = [p for p in sorted((args.source / "shards").glob("*.json")) if not p.name.startswith("_")]
    by_arm = {arm: [] for arm in ARMS}
    for path in shards:
        payload = json.loads(path.read_text(encoding="utf-8"))
        by_arm[payload["arm"]].append(payload["seed"])
    if any(sorted(seeds) != list(range(30)) for seeds in by_arm.values()):
        raise ValueError("Expected exactly the four specified arms, each with seeds 0 through 29")
    source_hashes_before = {entry["path"]: sha256(args.source / entry["path"]) for entry in manifest["files"]}
    episodes = []
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        jobs = [pool.submit(replay_one, (str(args.source), str(args.output), path.name)) for path in shards]
        for job in as_completed(jobs):
            episode = job.result()
            episodes.append(episode)
            if len(episodes) % 10 == 0:
                print(f"Replayed {len(episodes)}/120 episodes; simulator mismatches "
                      f"{sum(len(e['mismatches']) for e in episodes)}", flush=True)
    episodes.sort(key=lambda item: (ARMS.index(item["arm"]), item["seed"]))
    cache_status = Counter()
    cache_exception_outcomes = Counter()
    for episode in episodes:
        cache_status.update(episode["cache_attempt_status"])
        cache_exception_outcomes.update(attempt["historical_outcome"] for attempt in episode["cache_attempts"]
                                        if attempt["status"] != "matched")
    source_modified = [name for name, old_hash in source_hashes_before.items() if sha256(args.source / name) != old_hash]
    module_paths = sorted((ROOT / "src/twinloop").rglob("*.py"))
    module_paths += [ROOT / "src/twinloop/agent/prompts/llm_agent_v1.txt", Path(__file__),
                     ROOT / "scripts/gateway_uncertainty_ablation.py"]
    result = {
        "method": "Recompute simulator and scheduled counterfactuals from recorded action/trace streams; separately regenerate cached model decisions at every historical state.",
        "episodes": len(episodes), "seeds": list(range(30)), "arms": list(ARMS),
        "decision_points": sum(e["decision_points"] for e in episodes),
        "attempts": sum(e["attempts"] for e in episodes),
        "non_noop_candidates": sum(e["non_noop_candidates"] for e in episodes),
        "compared_record_fields": list(FIELDS),
        "simulator_mismatches": sum(len(e["mismatches"]) for e in episodes),
        "provider_calls": sum(e["provider_calls"] for e in episodes),
        "charged_calls": sum(e["budget_calls"] for e in episodes),
        "charged_tokens": sum(e["budget_tokens"] for e in episodes), "incremental_cost_usd": 0.0,
        "cache_replay_attempt_status": dict(cache_status),
        "cache_nonmatching_historical_outcomes": dict(cache_exception_outcomes),
        "limits": [
            "Action replay verifies simulation, candidate labels and gates; recorded model traces are supplied, so it does not independently establish how the model originally reasoned.",
            "Cache audit uses the original worker cache and historical states; after each diagnostic it restores the recorded action, so success counts are per attempt rather than a claim of full autonomous episode cache replay.",
            "The historical cache stores successful response text and visible input/output tokens, without provider errors, response timing, full prompts or returned provider model identity.",
            "Historical deadlines and failed provider requests are not reproducible from successful response entries alone; missing or different cache attempts must be replayed from the preserved decision trace.",
            "The original full configuration was not serialized; protocol and command-line defaults reconstruct 30-second provider timeout, 20-second decision timeout, four calls per attempt and reserve fraction 0.25.",
            "A0 is reused from the existing sweep by the study analysis and is not rerun here.",
        ],
        "artifact_manifest_mismatches": artifact_mismatches, "source_files_modified_during_audit": source_modified,
        "paper_main_sha256_before": paper_before, "paper_main_sha256_after": sha256(ROOT / "paper/main.tex"),
        "code_sha256": {path.relative_to(ROOT).as_posix(): sha256(path) for path in module_paths},
        "wall_seconds": time.perf_counter() - started, "per_episode": episodes,
    }
    (args.output / "replay_audit.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    archive = archive_artifacts(args.source, args.output, args.archive)
    print(json.dumps({key: value for key, value in result.items() if key not in ("per_episode", "code_sha256")}, indent=2))
    print(json.dumps({"archive": archive}, indent=2))
    if result["simulator_mismatches"] or artifact_mismatches or source_modified or paper_before != result["paper_main_sha256_after"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
