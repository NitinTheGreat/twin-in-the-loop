from __future__ import annotations

import json
from pathlib import Path


class BudgetExceeded(Exception):
    pass


class BudgetGuard:
    def __init__(self, max_calls: int, max_tokens: int, path=None) -> None:
        if max_calls < 0 or max_tokens < 0:
            raise ValueError("budget limits must be nonnegative")
        self.max_calls = max_calls
        self.max_tokens = max_tokens
        self.calls = 0
        self.tokens = 0
        self.path = Path(path) if path is not None else None
        self.pending_call = False
        self.pending_tokens = 0
        self.uncertain_tokens = 0
        if self.path is not None and self.path.exists():
            saved = json.loads(self.path.read_text(encoding="utf-8"))
            if (saved["max_calls"], saved["max_tokens"]) != (max_calls, max_tokens):
                raise ValueError("persisted budget limits differ from requested limits")
            self.calls = saved["calls"]
            self.tokens = saved["tokens"]
            self.pending_call = saved["pending_call"]
            self.pending_tokens = saved.get("pending_tokens", 0)
            self.uncertain_tokens = saved.get("uncertain_tokens", 0)
            if not isinstance(self.calls, int) or not isinstance(self.tokens, int):
                raise ValueError("persisted budget counters must be integers")
            if self.calls < 0 or self.tokens < 0 or not isinstance(self.pending_call, bool):
                raise ValueError("invalid persisted budget counters")

    def _persist(self) -> None:
        if self.path is None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(json.dumps({
            "max_calls": self.max_calls, "max_tokens": self.max_tokens,
            "calls": self.calls, "tokens": self.tokens, "pending_call": self.pending_call,
            "pending_tokens": self.pending_tokens, "uncertain_tokens": self.uncertain_tokens,
        }, sort_keys=True), encoding="utf-8")
        temporary.replace(self.path)

    def charge_call(self, token_reservation: int = 0) -> None:
        if self.path is not None and self.pending_call:
            raise BudgetExceeded("previous provider call has unresolved usage; reconcile budget ledger")
        if self.tokens >= self.max_tokens:
            raise BudgetExceeded(f"token ceiling of {self.max_tokens} reached")
        if token_reservation < 0:
            raise ValueError("token reservation must be nonnegative")
        if self.tokens + token_reservation > self.max_tokens:
            raise BudgetExceeded(f"remaining token budget cannot cover {token_reservation} reserved tokens")
        if self.calls + 1 > self.max_calls:
            raise BudgetExceeded(
                f"call ceiling of {self.max_calls} crossed"
            )
        self.calls += 1
        self.pending_call = True
        self.pending_tokens = token_reservation
        self._persist()

    def settle_failed_call(self) -> None:
        if self.pending_tokens <= 0:
            return
        self.tokens += self.pending_tokens
        self.uncertain_tokens += self.pending_tokens
        self.pending_tokens = 0
        self.pending_call = False
        self._persist()

    def charge_tokens(self, count: int, *, complete: bool = True) -> None:
        if count < 0:
            raise ValueError("token charge must be nonnegative")
        self.tokens += count
        self.pending_call = not complete
        self.pending_tokens = 0
        self._persist()
        if not complete and self.path is not None:
            raise BudgetExceeded("provider usage is incomplete; reconcile budget ledger")
        if self.tokens > self.max_tokens:
            raise BudgetExceeded(
                f"token ceiling of {self.max_tokens} crossed"
            )
