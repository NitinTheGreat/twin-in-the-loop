from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

from .budget import BudgetGuard
from .cache import CacheMiss, ResponseCache, cache_key


@dataclass
class LLMRecord:
    model: str
    latency_ms: float
    tokens_in: int
    tokens_out: int
    cache_hit: bool
    prompt_chars: int
    response_chars: int
    tokens_thinking: int = 0
    usage_metadata: dict = field(default_factory=dict)
    model_version: Optional[str] = None
    usage_complete: bool = False
    cache_key: Optional[str] = None


def canonical_prompt(messages: list[dict]) -> str:
    return json.dumps(messages, sort_keys=True, ensure_ascii=False)


class LLMClient:
    def __init__(
        self,
        provider,
        config,
        cache: Optional[ResponseCache] = None,
        budget: Optional[BudgetGuard] = None,
        log_path=None,
    ) -> None:
        self.provider = provider
        self.config = config
        self.cache = cache or ResponseCache(
            Path(config.cache_dir) / "cache.json",
            bypass=config.cache_bypass,
            cache_only=config.cache_only,
        )
        self.budget = budget or BudgetGuard(config.max_calls, config.max_tokens)
        self.log_path = Path(log_path) if log_path is not None else Path(config.log_path)
        self.records: list[LLMRecord] = []

    def complete(self, messages: list[dict], *, timeout_seconds=None) -> tuple[str, LLMRecord]:
        timeout = self.config.timeout_seconds
        if timeout_seconds is not None:
            timeout = min(timeout, timeout_seconds)
        if timeout <= 0:
            raise TimeoutError("no provider time remaining")
        prompt = canonical_prompt(messages)
        key = cache_key(self.config.model, self.config.temperature, prompt)

        cached = self.cache.get(key)
        if cached is not None:
            record = LLMRecord(
                model=self.config.model,
                latency_ms=0.0,
                tokens_in=cached["tokens_in"],
                tokens_out=cached["tokens_out"],
                cache_hit=True,
                prompt_chars=len(prompt),
                response_chars=len(cached["text"]),
                tokens_thinking=cached.get("tokens_thinking", 0),
                usage_metadata=cached.get("usage_metadata", {}),
                model_version=cached.get("model_version"),
                usage_complete=cached.get("usage_complete", False),
                cache_key=key,
            )
            self._log(record)
            return cached["text"], record

        if self.cache.cache_only:
            raise CacheMiss(f"cache-only mode: no entry for prompt {key[:12]}")

        self.budget.charge_call()
        start = time.perf_counter()
        response = self.provider.complete(
            messages,
            self.config.model,
            self.config.temperature,
            timeout,
        )
        latency_ms = (time.perf_counter() - start) * 1000.0
        self.cache.put(
            key,
            {
                "text": response.text,
                "tokens_in": response.tokens_in,
                "tokens_out": response.tokens_out,
                "tokens_thinking": response.tokens_thinking,
                "usage_metadata": response.usage_metadata,
                "model_version": response.model_version,
                "usage_complete": response.usage_complete,
                "latency_ms": latency_ms,
            },
        )
        record = LLMRecord(
            model=self.config.model,
            latency_ms=latency_ms,
            tokens_in=response.tokens_in,
            tokens_out=response.tokens_out,
            cache_hit=False,
            prompt_chars=len(prompt),
            response_chars=len(response.text),
            tokens_thinking=response.tokens_thinking,
            usage_metadata=response.usage_metadata,
            model_version=response.model_version,
            usage_complete=response.usage_complete,
            cache_key=key,
        )
        self._log(record)
        self.budget.charge_tokens(response.tokens_in + response.tokens_out,
                                  complete=response.usage_complete)
        return response.text, record

    def _log(self, record: LLMRecord) -> None:
        self.records.append(record)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(asdict(record)) + "\n")
