# Live-model descriptive study: what a real LLM proposes, and how the gate classifies it

Date: 2026-09-20. **This is the project's first live-model data.** 30 seeds, 4 arms,
120 episodes, all against a real hosted model. `paper/main.tex` was not modified.
Machine-readable results: `docs/research/llm_descriptive_study.json`.

Purpose is descriptive, as specified: what does a real model propose, and how does the gate
classify those proposals. **No episode-level effect is claimed at 30 seeds.**

## Bottom line

1. **The model does not collapse to `no_op`.** It produces a schema-valid, semantically valid
   action at **52.8–63.1%** of decision points. The old cached-Gemini observation of "~97%
   `no_op`" does not reproduce with this model and prompt version.
2. **Its action mix is qualitatively different from both scripted controllers.** Ungated, it
   splits 39.7% scale / 31.7% restart / 28.6% migrate. The rule controller is 81.4% scale and
   the scripted stub is 100% scale. **The live model is the only controller in this project
   that proposes restarts and migrations at scale**, which are the high-value repairs.
3. **Its proposals are mostly harmful.** Ungated, 147 of 227 candidates (64.8%) have D > 0,
   totalling 915 violation-ticks of available harm against 438 of available benefit. Ungated it
   scores 149.6 violation-ticks against the A0 null's 124.8 — **worse than doing nothing**, by
   +24.7 ticks (exact Wilcoxon p = 3.7 × 10⁻⁶, 27 of 30 seeds worse). That comparison *is*
   adequately powered.
4. **The gate classifies those proposals well.** At τ = 0, θ = 3, twin@1.0 has recall
   **0.989** [0.973, 1.000] and precision 0.881 on 249 candidates. On the τ = θ = 3 diagonal,
   FPR drops from 0.403 to **0.048** with recall unchanged, because **24 of its 25 false
   positives (96%) are definitional** — actions with 0 < D ≤ 3.
5. **Roughly one decision in five fails to produce a parseable action.** 15.8% (ungated) to
   19.4% (twin@0.6) of decision points end in a classified failure, dominated by
   `final_parse_failure` (14.7–19.6% of attempts). Every one falls back to a safe `no_op` and
   is recorded as `fallback=true`, so the collapse is classified, never silent.
6. **Episode-level gate comparisons are underpowered at 30 seeds and are not claims.**
   twin@1.0 − reject-all is −4.30 [−9.16, +0.56], p = 0.055, **observed power 0.47, and about
   72 seeds would be needed**. twin@0.6 − reject-all is −1.30, p = 0.51, power 0.11, ~451 seeds.
   Neither is significant, and neither is presented as a null result.
7. **Opportunity is as scarce as in the sweep.** Seeds with at least one beneficial candidate:
   25/30 ungated, but only **12/30 on the reject-all trajectory** and 10/30 at twin@1.0.

---

## Provenance and cost

| Item | Value |
|---|---|
| Model | **gemini-3.6-flash** (the repo's `PROVIDER_PRESETS["gemini"]` model) |
| Provider | Google Generative Language API, `https://generativelanguage.googleapis.com/v1beta`, `GeminiProvider` |
| Credential | `GEMINI_API_KEY`, read from the gitignored `.env`; never printed or logged |
| Temperature | 0.0 |
| Prompt version | `v1` (`src/twinloop/agent/prompts/`), ReAct loop, `react_max_steps = 4`, final-call reservation active |
| Cache key policy | `sha256(model, temperature, canonical JSON of the full message list)`; a hit returns the stored reply and makes **no** provider call. Caches are per worker, under the session scratchpad |
| Protocol | Published: 120-tick episodes, decision every 10 ticks, retry cap 2, twin horizon 20, τ = 0, θ = 3, gateway immune |
| Seeds | 30, contiguous 0–29 |
| Arms | LLM ungated, LLM reject-all, LLM twin@1.0, LLM twin@0.6 |
| A0 reference | Reused from the 150-seed sweep, not re-run |

**Fidelity choice, justified from the sweep.** 1.0 is the established useful operating point
(the only level where the rule controller's episode advantage over reject-all is significant,
and where `benefit_preserved` jumps to 0.97). 0.6 sits just above the scripted controller's
net-Σ-D crossover at 0.549 [0.434, 0.677], so it is the nearest level to the sign change.

### Actual spend

| | Calls | Input tokens | Output tokens |
|---|---|---|---|
| **Billed (provider calls)** | **5,644** | **11,498,743** | **509,258** |
| Served from cache, not billed | 2,657 | 5,189,527 | 256,524 |
| Recorded total | 8,301 | 16,688,270 | 765,782 |

**Billed cost: $10.53** at the published paid-tier rates for gemini-3.6-flash ($0.75 per 1M
input, $3.75 per 1M output, the rates in force through 2026-12-31). The cache avoided about
$4.85 of additional spend. Wall clock: 4.8 hours of episode time, about 75 minutes real time
across 4 workers plus a 17-minute 2-seed pilot.

**Two disclosures about the budget guard.**

- **Before the run**, a 2-seed pilot measured 167 charged calls and ~360k tokens per seed,
  projecting ~5,000 calls and ~10.8M tokens for 30 seeds — under the authorised 9,000 call /
  20M token ceiling. The projection held: **5,655 charged calls, 12,008,001 tokens**.
- **The ceiling was not enforced as a single global cap.** `BudgetGuard` is per process, so the
  pilot (9,000) and the four workers (2,000 each) summed to 17,000 calls / 38M tokens of
  headroom. Actual usage stayed inside the intended 9,000/20M by measurement, not by
  enforcement. A single-process run, or a shared guard, would be needed to make that ceiling
  hard. No arm stopped early; `stopped_early` is null for every worker.
- **My pre-run cost estimate was wrong.** I told you $1–5 for a "cheap flash tier"; the actual
  rate is $0.75/$3.75 per million, so the real figure is $10.53. The token projection was
  accurate; the price assumption was not.

### Validity checks

- **Reject-all reproduces the A0 null exactly**: identical violation-ticks on all 30 seeds
  (124.83 mean, 0 mismatches against the sweep's `a0_per_seed[:30]`). Rejecting every non-no-op
  proposal is doing nothing, as in the sweep.
- **The recorded verdict is reconstructed from predicted deltas at τ = 0**: 249/249 and 245/245
  on the two twin arms, 0 mismatches.
- **The reject-all arm is excluded from all τ/θ and confusion analysis.** It runs no simulation,
  so its predicted deltas are identically 0 and a confusion matrix over them is meaningless.
- **Timeouts and provider errors were negligible**: 13 timeouts across 2,110 decision attempts
  (0.6%), 0 provider errors, 0 budget exhaustions. Rate limiting did not contaminate the
  outcome distribution.

### Reproduce

```powershell
.\.venv\Scripts\python.exe scripts\llm_descriptive_study.py run --shards <dir>\shards --workdir <dir>\w<k> --cache-dir <dir>\cache_w<k> --seed-count 30 --worker <k> --workers 4 --max-calls 2000 --max-tokens 4500000
.\.venv\Scripts\python.exe scripts\llm_descriptive_study.py analyze --shards <dir>\shards --output docs\research\llm_descriptive_study.json --calls-log-root <dir> --price-in 0.75 --price-out 3.75
```

Workers write one file per episode and skip episodes already present, so an interrupted run
resumes without re-paying. With the caches retained, a re-run is served entirely from cache.

---

# 1. Decision outcome distribution (primary deliverable)

The taxonomy is the existing one from `docs/research/test_suite_audit.md`. Two views: **per
attempt** (every `decide()` call, including gate-rejection retries) and **per decision point**
(first attempt only, 12 per episode × 30 seeds = 360 per arm). Percentages are of that arm's
total.

## Per decision point (360 per arm)

| Outcome | ungated | reject-all | twin@1.0 | twin@0.6 |
|---|---|---|---|---|
| `decision_produced` | **227 (63.1%)** | **187 (51.9%)** | **190 (52.8%)** | **189 (52.5%)** |
| `deliberate_no_op` | 76 (21.1%) | 105 (29.2%) | 102 (28.3%) | 101 (28.1%) |
| `final_parse_failure` | 53 (14.7%) | 64 (17.8%) | 67 (18.6%) | 69 (19.2%) |
| `validation_exhausted` | 2 (0.6%) | 0 | 1 (0.3%) | 0 |
| `tool_budget_exhausted` | 1 (0.3%) | 2 (0.6%) | 0 | 0 |
| `timeout` | 1 (0.3%) | 2 (0.6%) | 0 | 1 (0.3%) |
| `provider_budget_exhausted` | 0 | 0 | 0 | 0 |
| `provider_error` | 0 | 0 | 0 | 0 |
| **Classified failures (fallback to `no_op`)** | **57 (15.8%)** | **68 (18.9%)** | **68 (18.9%)** | **70 (19.4%)** |

## Per attempt (includes gate-rejection retries)

| Outcome | ungated (360) | reject-all (660) | twin@1.0 (550) | twin@0.6 (540) |
|---|---|---|---|---|
| `decision_produced` | 227 (63.1%) | 394 (59.7%) | 249 (45.3%) | 245 (45.4%) |
| `deliberate_no_op` | 76 (21.1%) | 160 (24.2%) | 192 (34.9%) | 181 (33.5%) |
| `final_parse_failure` | 53 (14.7%) | 92 (13.9%) | 106 (19.3%) | 106 (19.6%) |
| `validation_exhausted` | 2 (0.6%) | 7 (1.1%) | 1 (0.2%) | 2 (0.4%) |
| `tool_budget_exhausted` | 1 (0.3%) | 2 (0.3%) | 1 (0.2%) | 0 |
| `timeout` | 1 (0.3%) | 5 (0.8%) | 1 (0.2%) | 6 (1.1%) |

**Reading.**

- **No `no_op` collapse.** Counting both paths to inaction — deliberate holds plus fallbacks —
  the model is inactive at 36.9% (ungated) to 47.5% (twin@0.6) of decision points. That is a
  long way from the ~97% previously reported for the cached Gemini arm.
- **`final_parse_failure` is the dominant failure and it is substantial**: about 1 in 6
  decisions ungated, rising to about 1 in 5 behind a gate. The model exhausts its four turns
  without emitting a JSON object matching the action schema. Each such decision falls back to a
  safe `no_op` carrying `fallback=true`, so it is visible in the logs rather than being
  mistaken for a deliberate hold — which is exactly what the finalization work in the test-suite
  audit was for.
- **Retries after a rejection rarely produce a new action.** In the reject-all arm, 660
  attempts across 360 decision points produced 394 actions, but the retry attempts skew toward
  `deliberate_no_op` (160 across the arm versus 105 at first attempt). This matches the
  scripted stub's retry behaviour reported in `candidate_composition.md`, though unlike the
  stub the model does sometimes propose a genuinely different action.
- **Behind a gate the model is less decisive**: `decision_produced` per attempt falls from 63.1%
  (ungated) to about 45% in the twin arms, and `deliberate_no_op` rises to about 34%.

---

# 2. Action-type mix, and how it compares to the other controllers

Of decisions that produced an action (`decision_produced`):

| Controller / arm | Produced | migrate | restart | scale | throttle |
|---|---|---|---|---|---|
| **LLM ungated** | 227 | 28.6% | **31.7%** | 39.7% | 0 |
| **LLM reject-all** | 394 | **53.6%** | 7.6% | 38.3% | 0.5% |
| **LLM twin@1.0** | 249 | **53.4%** | 14.1% | 32.5% | 0 |
| **LLM twin@0.6** | 245 | **55.1%** | 14.7% | 29.8% | 0.4% |
| Rule ungated (sweep, 150 seeds) | 204 | 11.8% | 6.4% | **81.4%** | 0.5% |
| Rule twin@1.0 (sweep) | 159 | 12.6% | 7.6% | **79.3%** | 0.6% |
| Scripted stub, any arm (sweep) | 1,260 | 0 | 0 | **100%** | 0 |

**This is the clearest descriptive contrast in the study.** The scripted stub can only scale;
the rule controller scales four times out of five. The live model distributes across the action
space: ungated it restarts more often than it migrates, and behind a gate it migrates in more
than half of its proposals. It is also the only controller that ever proposes `throttle_service`
in these runs (3 proposals).

The shift between ungated and gated arms is a trajectory effect, not a change of policy: once
harmful actions are blocked, the network stays degraded and the model keeps proposing
migrations against persistent faults.

---

# 3. Candidate composition

Non-no-op proposals only, each arm on its own trajectory. D = V₂₀(action, then no-op) −
V₂₀(no-op); D < 0 beneficial. Magnitudes are min / median / p90 / max.

| Arm | Candidates | Beneficial | Neutral | Harmful (D>3) | Available benefit | Available harm | Beneficial \|D\| | Harmful D | **Seeds with benefit** |
|---|---|---|---|---|---|---|---|---|---|
| ungated | 227 | 55 (24.2%) | 25 | 147 (101) | 438 | 915 | 1 / 8 / 13 / 27 | 1 / 6 / 11 / 17 | **25 / 30** |
| reject-all | 394 | 32 (8.1%) | 35 | 327 (292) | **252** | 2,452 | 1 / 7 / 17 / 29 | 1 / 8 / 11 / 26 | **12 / 30** |
| twin@1.0 | 249 | 12 (4.8%) | 23 | 214 (187) | **112** | 1,614 | 1 / 8 / 17 / 29 | 1 / 7 / 11 / 27 | **10 / 30** |
| twin@0.6 | 245 | 15 (6.1%) | 25 | 205 (180) | **146** | 1,568 | 1 / 8 / 17 / 29 | 1 / 8 / 11 / 27 | **12 / 30** |

By action type, ungated (benefit / harm in violation-ticks):

| Action | Beneficial | Neutral | Harmful | Benefit | Harm |
|---|---|---|---|---|---|
| scale_service | 40 | 6 | 44 | 275 | 338 |
| restart_service | 5 | 17 | 50 | 67 | 137 |
| migrate_service | 10 | 2 | 53 | 96 | 440 |

**Reading.** Ungated, about a quarter of the model's candidates are beneficial, which is better
than the scripted stub (17%) and comparable to the rule controller (30% in the sweep). But its
migrations are mostly harmful here (53 of 65), and migrations carry the largest harm magnitudes.
Its restarts are mostly neutral-to-harmful on these trajectories, unlike the rule controller's
restarts, which were the single highest-value repair in the sweep.

As in every previous experiment, gating collapses the opportunity: the benefit available on the
reject-all trajectory is 252 ticks across 12 seeds, and on the twin@1.0 trajectory 112 ticks
across 10 seeds.

---

# 4. benefit_preserved, harm_prevented, net Σ D

Definitions as in `candidate_composition.md` Analysis B. Bootstrap CIs are seed-level, 5,000
resamples. **"n/e" would mark a zero denominator; none occurs here.**

| Arm | benefit_preserved [95% CI] | (appr/avail) | harm_prevented [95% CI] | (rej/avail) | **Net Σ D per seed** | bootstrap CI | Seeds ≠ 0 | Net total |
|---|---|---|---|---|---|---|---|---|
| reject-all (reference) | **0.000** [0.000, 0.000] | 0 / 252 | **1.000** [1.000, 1.000] | 2,452 / 2,452 | **0.000** | [0, 0] | 0 | 0 |
| twin@1.0 | **1.000** [1.000, 1.000] | 112 / 112 | 0.990 [0.980, 0.998] | 1,598 / 1,614 | **−3.200** | [−6.767, −0.667] | 13 | −96 |
| twin@0.6 | 0.603 [0.446, 0.933] | 88 / 146 | 0.969 [0.943, 0.988] | 1,520 / 1,568 | **−1.333** | [−3.533, +0.500] | 13 | −40 |
| ungated (reference) | 1.000 [1.000, 1.000] | 438 / 438 | 0.000 [0.000, 0.000] | 0 / 915 | **+15.900** | [+11.967, +19.867] | 30 | +477 |

**Reading.** Against a live model, twin@1.0 preserves **all** of the available benefit while
blocking 99% of the harm, and its approved set is locally better than rejecting everything by
3.2 ticks per seed with a CI excluding zero. twin@0.6 keeps only 60% of the benefit, and its
net Σ D interval includes zero. This ordering — 1.0 clearly better than 0.6 on the local metric
— matches the sweep's finding that the useful operating region is 0.8–1.0.

The ungated row quantifies the problem the gate exists to solve: +15.9 ticks per seed of net
harm admitted, on 30 of 30 seeds.

---

# 5. Confusion matrices, τ = 0 / θ = 3 and the τ = θ = 3 diagonal

Corpus: every non-no-op candidate with both a predicted and a counterfactual delta. Definitional
false positives are rejections with τ < D ≤ θ — real harm, below where θ sits. On the diagonal
that band is empty by construction, so every false positive there is genuine predictive error.

**twin@1.0** — 249 candidates: 12 beneficial, 23 neutral, 214 with D > 0 (187 with D > 3).
Predicted delta min −29, median +7, p90 +11, max +15. Recorded verdict matches τ = 0 on 249/249.

| τ | θ | TP / FN / FP / TN | Recall [95% CI] | FPR [95% CI] | Precision | FP definitional | FP predictive | Definitional share |
|---|---|---|---|---|---|---|---|---|
| **0** | **3** | 185 / 2 / 25 / 37 | **0.989** [0.973, 1.000] | **0.403** [0.275, 0.545] | 0.881 | **24** | 1 | **0.960** |
| **3 =** | **3** | 185 / 2 / 3 / 59 | **0.989** [0.973, 1.000] | **0.048** [0.000, 0.104] | 0.984 | **0** | 3 | **0.000** |

**twin@0.6** — 245 candidates: 15 beneficial, 25 neutral, 205 with D > 0 (180 with D > 3).
Predicted delta min −27, median +6, p90 +12, max +21. Verdict matches τ = 0 on 245/245.

| τ | θ | TP / FN / FP / TN | Recall [95% CI] | FPR [95% CI] | Precision | FP definitional | FP predictive | Definitional share |
|---|---|---|---|---|---|---|---|---|
| **0** | **3** | 175 / 5 / 21 / 44 | 0.972 [0.941, 0.995] | 0.323 [0.194, 0.472] | 0.893 | 16 | 5 | 0.762 |
| **3 =** | **3** | 154 / 26 / 6 / 59 | 0.856 [0.797, 0.909] | **0.092** [0.033, 0.162] | 0.963 | 0 | 6 | 0.000 |

**Reading.**

- **The published τ = 0, θ = 3 FPR of 0.403 is almost entirely definitional.** 24 of 25 false
  positives at fidelity 1.0 are actions with 0 < D ≤ 3, which really do cause harm. On the
  diagonal, recall is unchanged (0.989) and FPR falls to 0.048 with only **3** genuine
  predictive errors, none of them a rejection of a beneficial action.
- **This reproduces the sweep's finding on live-model proposals.** The scripted controller's
  definitional share at fidelity 1.0 was 83.6%; here it is 96.0%.
- **Fidelity 0.6 is visibly worse as a predictor**, and in the honest direction: on the diagonal
  its recall drops to 0.856 with 26 missed harmful actions, and 4 of its 21 false positives at
  τ = 0 are rejections of genuinely beneficial actions (against 0 for fidelity 1.0).

---

# 6. Episode-level paired differences (underpowered; not claims)

Difference = arm − reject-all, in episode violation-ticks, paired per seed, n = 30. Power is the
bootstrap-estimated power of the exact Wilcoxon test at n = 30 on the observed differences.

| Comparison | Mean | 95% t-CI | Bootstrap CI | SD | Non-zero (B/W) | Exact Wilcoxon p | Holm p | Significant? | **Observed power** | **Seeds for 80%** |
|---|---|---|---|---|---|---|---|---|---|---|
| **ungated − reject-all** | **+24.733** | [+16.74, +32.73] | [+17.10, +32.00] | 21.41 | 28 (1/27) | **3.7 × 10⁻⁶** | **1.5 × 10⁻⁵** | **Yes — ungated is worse** | 1.00 | 6 |
| twin@1.0 − reject-all | −4.300 | [−9.16, +0.56] | [−9.37, −0.50] | 13.01 | 12 (8/4) | 0.055 | 0.109 | **No** | **0.47** | **72** |
| twin@0.6 − reject-all | −1.300 | [−4.98, +2.38] | [−4.83, +2.13] | 9.85 | 14 (7/7) | 0.512 | 0.512 | **No** | **0.11** | **451** |
| twin@1.0 − twin@0.6 | −3.000 | [−5.78, −0.22] | [−5.80, −0.67] | 7.44 | 10 (8/2) | 0.027 | 0.082 | No after Holm | 0.63 | 49 |

**What may and may not be said.**

- **Adequately powered:** the live model ungated is worse than doing nothing, by about 25
  violation-ticks per episode, on 27 of 30 seeds. This is the strongest statement the study
  supports, and it is about the *model*, not the gate.
- **Not established, and not a null either:** whether the twin gate beats reject-all. The point
  estimate is −4.3 ticks in the gate's favour with 8 of 12 differing seeds improved, p = 0.055,
  **but observed power is only 0.47** — this design would miss a real effect of that size more
  than half the time. About **72 seeds** would be needed at the observed variance. The same
  applies more strongly to twin@0.6 (power 0.11, ~451 seeds).
- The twin@1.0 versus twin@0.6 contrast (−3.0, p = 0.027 unadjusted) does not survive Holm
  adjustment and is likewise underpowered.

---

# 7. Seeds containing at least one beneficial candidate

| Arm | Seeds with ≥ 1 beneficial candidate | Available benefit on that trajectory |
|---|---|---|
| ungated | **25 / 30 (83%)** | 438 ticks |
| reject-all | **12 / 30 (40%)** | 252 ticks (8.4 per seed) |
| twin@1.0 | **10 / 30 (33%)** | 112 ticks |
| twin@0.6 | **12 / 30 (40%)** | 146 ticks |

The reject-all column is the ceiling on what any gate can recover, as in the sweep. At 8.4 ticks
per seed it is **24× larger than the scripted stub's 0.35** and about 2.9× the rule
controller's, which is why the twin@1.0 point estimate here (−4.3) is larger than the rule
controller's established effect (−2.32) despite far fewer seeds. **A live model that proposes
real repairs creates the headroom that the scripted controllers never did** — which is the most
useful thing this study contributes to the evaluation design.

---

# Interpretation

1. **The paper's LLM framing now has data behind it.** A real model, at the published protocol,
   proposes actions at about half of all decision points and uses the full action space. The
   previously reported `no_op` collapse is not a property of live models in general; it was a
   property of that earlier arm.
2. **Describe the model as unsafe-by-default rather than passive.** Ungated it is significantly
   worse than inaction (+24.7 ticks, p = 3.7 × 10⁻⁶). That is the motivating problem for a gate,
   and it is now measured rather than assumed.
3. **Report the gate against a live model as a classifier, not as an episode-level win.** Recall
   0.989 and, on the τ = θ diagonal, FPR 0.048 with 3 predictive errors in 249 candidates. The
   episode comparison at 30 seeds is underpowered (0.47) and must be quoted with its power and
   its ~72-seed requirement.
4. **Reliability is a reportable weakness.** About one decision in five ends in
   `final_parse_failure`. It is safely handled — every failure becomes a classified `no_op`
   fallback — but a fifth of decisions never reach the gate at all, and any claim about
   "an LLM agent operating the network" should state that.
5. **The obvious next experiment** is this same arm set at 72+ seeds, which the pilot-measured
   cost puts at roughly $25–30 and 3 hours wall time. That would settle the episode-level
   question for the live model as the 150-seed sweep settled it for the rule controller.

---

# Files

- `scripts/llm_descriptive_study.py`: the runner (`run`, resumable, seed-partitioned, budget
  guarded, cache-backed) and the analyzer (`analyze`). It reuses the sweep's statistics helpers
  — `per_seed_candidate_arrays`, `ratio_with_ci`, `mean_with_ci`, `composition_detail`,
  `candidate_corpus`, `tau_theta_grid`, `episode_comparison`, `wilcoxon_exact_dp`, `holm` —
  from `scripts/gateway_uncertainty_ablation.py` rather than reimplementing them.
- `docs/research/llm_descriptive_study.json`: provenance, billed and cached usage, per-arm
  outcome distributions, action mixes, composition, gate metrics with CIs, the full τ/θ grid for
  both twin arms, episode comparisons with power, and per-seed episode totals.
- `paper/main.tex`: not touched.
- The 120 raw per-episode shard files, the four response caches and the per-call logs are in the
  session scratchpad. With the caches, a re-run costs nothing.
